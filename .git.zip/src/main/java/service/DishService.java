package service;

import java.util.ArrayList;
import java.util.List;

import dao.DishDAOImpl;
import model.Dish;
import model.Tag;

public class DishService {

	public static DishDAOImpl dd = new DishDAOImpl();
	
	public static Dish selectDishById(int id) {
		return dd.selectDishById(id);
	}
	
	public static List<Dish> selectAllDishes() {
		List<Dish> allDishes = dd.selectAllDishes();
		return allDishes;
	}
	
	public static List<Dish> selectDishesByTags(List<Tag> tags) {
		List<Dish> dishes = dd.selectDishesByTags(tags);
		return dishes;
	}
	
	public static int insertDish(Dish d) {
		return dd.insertDish(d);
	}
	
	public static void updateDish(Dish change) {
		dd.updateDish(change);
	}
	
	public static void deleteDishById(int id) {
		dd.deleteDishById(id);
	}
}
